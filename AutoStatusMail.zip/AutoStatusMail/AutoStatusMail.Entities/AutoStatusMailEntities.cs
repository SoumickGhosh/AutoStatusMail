﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoStatusMail.Entities
{
    public class AutoStatusMailEntities
    {
        public DateTime CreationDate { get; set; }
        public string Priority { get; set; }
        public DateTime SLAMaxDateActual { get; set; }
        public string Status { get; set; }
        public DateTime ITCompleteDate { get; set; }
        public float ResolutionDays { get; set; }
        public string MetResolutionMax { get; set; }
    }
}
