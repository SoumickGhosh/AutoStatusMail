﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AutoStatusMail.BL;
using AutoStatusMail.Entities;

namespace AutoStatusMailUI
{
    public partial class AutoStatusMailManager : Form
    {
        public AutoStatusMailManager()
        {
            InitializeComponent();
        }
        AutoStatusMailBL autoStatusMailBL = null;
        private void btnReadExcelSheet_Click(object sender, EventArgs e)
        {
            autoStatusMailBL = new AutoStatusMailBL();
            IEnumerable<AutoStatusMailEntities> xlWorkBook = autoStatusMailBL.ReadExcelSheetDataBL();
            MessageBox.Show("Total Rows: "+xlWorkBook.Count());
        }

        private void btnCompleteCurrentMonth_Click(object sender, EventArgs e)
        {
            autoStatusMailBL = new AutoStatusMailBL();
            IEnumerable < AutoStatusMailEntities > totalResolvedCurrentMonth= autoStatusMailBL.CheckTotalResolvedForCurrentMonthBL();
            MessageBox.Show("Total Rows: "+totalResolvedCurrentMonth.Count());
        }
    }
}
