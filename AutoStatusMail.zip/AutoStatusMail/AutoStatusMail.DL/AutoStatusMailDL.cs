﻿using AutoStatusMail.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoStatusMail.DL
{
    public class AutoStatusMailDL
    {
        
        public IEnumerable<AutoStatusMailEntities> ReadExcelSheetDataDL(string xlFilePath,string xlWorkSheetName)
        {
            ReadExcelSheet readExcelSheet = new ReadExcelSheet();
            IEnumerable<AutoStatusMailEntities> dsWorkBook = readExcelSheet.ReadExcel(xlFilePath, xlWorkSheetName);
            return dsWorkBook;
        }
        public IEnumerable<AutoStatusMailEntities> CheckTotalResolvedForCurrentMonthDL(string xlFilePath,string xlWorkSheetName)
        {
            CheckCompleteDateCurrentMonth checkCompleteDateCurrentMonth = new CheckCompleteDateCurrentMonth();
            IEnumerable<AutoStatusMailEntities> totalresolvedCurrentMonthList= checkCompleteDateCurrentMonth.ApplyCompleteDateFilterForCurrentMonth(xlFilePath, xlWorkSheetName);
            return totalresolvedCurrentMonthList;
        }

    }
}
