﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoStatusMail.Entities;
using Microsoft.Office.Interop.Excel;
using _Excel = Microsoft.Office.Interop.Excel;


namespace AutoStatusMail.DL
{
    class CheckCompleteDateCurrentMonth : ICheckCompleteDateCurrentMonth
    {
        public IEnumerable<AutoStatusMailEntities> ApplyCompleteDateFilterForCurrentMonth(string xLFilePath, string xlWorkSheetName)
        {
            ReadExcelSheet readExcelSheet = new ReadExcelSheet();
            var today = DateTime.Today;
            var month = new DateTime(today.Year, today.Month, 1);
            var first = month.AddMonths(-1);
            var last = month.AddDays(-1);
            IEnumerable<AutoStatusMailEntities> readExcelSheetList = readExcelSheet.ReadExcel(xLFilePath, xlWorkSheetName);
            IEnumerable<AutoStatusMailEntities> checkCompleteDateCurrentMonth = readExcelSheetList.Where(p=> p.ITCompleteDate>first && p.ITCompleteDate<last);
            return checkCompleteDateCurrentMonth;
        }
    }
}
