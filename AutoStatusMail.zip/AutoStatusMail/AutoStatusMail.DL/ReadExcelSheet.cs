﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoStatusMail.Entities;

namespace AutoStatusMail.DL
{
    class ReadExcelSheet : IReadExcelSheet
    {
        public IEnumerable<AutoStatusMailEntities> ReadExcel(string xLFilePath, string xlWorkSheetName)
        {
            DataSet dsWorkBook = new DataSet();
            dynamic WorkBookList=null;
            string connectionString = string.Empty;
            switch (Path.GetExtension(xLFilePath).ToUpperInvariant())
            {
                case ".XLS":
                    connectionString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0}; Extended Properties= Excel 8.0;", xLFilePath);
                    break;

                case ".XLSX":
                    connectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0}; Extended Properties= Excel 12.0;", xLFilePath);
                    break;
            }
            if(!String.IsNullOrEmpty(connectionString))
            {
                string selectStatement = string.Format("SELECT * FROM [{0}$]", xlWorkSheetName);
                using (OleDbDataAdapter dataAdapter = new OleDbDataAdapter(selectStatement,connectionString))
                {
                    dataAdapter.Fill(dsWorkBook, xlWorkSheetName);
                    WorkBookList = dsWorkBook.Tables[0].AsEnumerable().Select
                        (s => new AutoStatusMailEntities
                        {CreationDate=Convert.ToDateTime(s["Creation DtTm"]!=DBNull.Value? s["Creation DtTm"]:"1-1-1900"),
                        Priority=Convert.ToString(s["Priority"] != DBNull.Value ? s["Priority"] : ""),
                        SLAMaxDateActual=Convert.ToDateTime(s["SLA Max Date_(Actual)"] != DBNull.Value ? s["SLA Max Date_(Actual)"]: "1-1-1900"),
                        Status=Convert.ToString(s["Status"] != DBNull.Value ? s["Status"] : ""),
                        ITCompleteDate= Convert.ToDateTime(s["IT Complete DtTm"] != DBNull.Value ? s["IT Complete DtTm"] : "1-1-1900"),
                        ResolutionDays= Convert.ToSingle(s["Resolution Days"] != DBNull.Value ? s["Resolution Days"] : "0.00"),
                        MetResolutionMax=Convert.ToString(s["Met Resolution SLA_(Max)"] != DBNull.Value ? s["Met Resolution SLA_(Max)"] : "")
                        }).ToList();
                }
            }
            return WorkBookList;
        }
    }
}
