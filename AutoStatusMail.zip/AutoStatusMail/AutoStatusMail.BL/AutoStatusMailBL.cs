﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoStatusMail.DL;
using AutoStatusMail.Entities;

namespace AutoStatusMail.BL
{
    public class AutoStatusMailBL
    {
        AutoStatusMailDL autoStatusMailDL = null;
        string xlFilePath = "D:\\L2 Tracker02.xlsx";
        string xlWorkSheetName = "Tickets - Current";
        public IEnumerable<AutoStatusMailEntities> ReadExcelSheetDataBL()
        {
            autoStatusMailDL = new AutoStatusMailDL();
            IEnumerable<AutoStatusMailEntities> dsWorkBook = autoStatusMailDL.ReadExcelSheetDataDL(xlFilePath, xlWorkSheetName);
            return dsWorkBook;
        }
        public IEnumerable<AutoStatusMailEntities> CheckTotalResolvedForCurrentMonthBL()
        {
            autoStatusMailDL = new AutoStatusMailDL();
            IEnumerable<AutoStatusMailEntities> totalResolvedCurrentMonthList = autoStatusMailDL.CheckTotalResolvedForCurrentMonthDL(xlFilePath, xlWorkSheetName);
            return totalResolvedCurrentMonthList;
        }
    }
}
